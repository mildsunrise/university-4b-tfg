This annex contains tooling and other code developed during the project.

The directories are:

 - `analysis`: Tooling to run experiments and analyze their data.

   - `load.py`: Code for load processes started up within experiments.

   - `experiment.py`: Script that starts a full experiment inside a UML kernel. The path to the compiled kernel can be specified at `kernel_path` in the script.

   - `live_experiment.py`: Modified version of `experiment.py` that runs the experiment directly on the host, and uses a real command instead of an offender load. The command to execute can be specified at `main_command` in the script.

   - `timeline.ipynb`: Jupyter notebook to parse and analyze the data produced by experiment runs.

   - `kernel_config`: Configuration used to compile the UML kernel.

 - `daemon`: Userspace daemon that listens for heavy writing processes and lowers their I/O priority to reduce pauses. See internal `README` for more info.

 - `monitor`: Web application that plots the state of the cache in real time. See internal `README` for more info.

 - `misc`: Contains other code produced during the project.

   - `trace-cmd.patch`: Patches applied to `trace-cmd` source code to get functional Python bindings.

   - `misc/tracecmd`: Contains the compiled Python bindings for `trace-cmd` under x86_64, after applying said patches. (`timeline.ipynb` uses these bindings to parse the tracer dump files)

