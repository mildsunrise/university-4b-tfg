Real time plot of the page cache state.

![Screenshot](../memory/img/development/monitor-screenshot-1.png)

## Usage

Install dependencies:

~~~
npm install
~~~

Start as root:

~~~
sudo node server
~~~

Needs a recent Node.JS version due to a bug in `writeFileSync`.
